/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema_6;

import java.util.Scanner;
public class Problema_6 {
    public static void main(String[] args) {
       Scanner dato = new Scanner(System.in);
       int num1,num2,x=0;
        System.out.println("escriba dos numero diferentes");
        num1 = dato.nextInt();
        num2 = dato.nextInt();
        
    }
    
}
